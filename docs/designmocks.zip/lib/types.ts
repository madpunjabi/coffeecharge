export type ConnectorType = "CCS" | "CHAdeMO" | "NACS" | "J1772"

export type ChargingNetwork = "Tesla Supercharger" | "Electrify America" | "ChargePoint" | "EVgo" | "Blink"

export type StallStatus = "available" | "occupied" | "broken" | "unknown"

export type ReliabilityLevel = "high" | "medium" | "low"

export interface Stall {
  id: string
  status: StallStatus
  powerKw: number
  connector: ConnectorType
}

export interface ChargeScore {
  overall: number // 1-5
  uptimeHistory: number
  realTimeAvailability: number
  communityVerification: number
  networkBenchmark: number
}

export interface BrewScore {
  overall: number // 1-5
  foodOptions: number
  restroomAccess: number
  retailQuality: number
  venueQuality: number
  environment: number
  hoursCoverage: number
}

export interface Amenity {
  id: string
  name: string
  brand: string
  category: "coffee" | "food" | "grocery" | "retail" | "restroom" | "hotel" | "gas"
  walkMinutes: number
  rating: number
  isOpenNow: boolean
  hours: string
  distance: string
}

export interface Station {
  id: string
  name: string
  network: ChargingNetwork
  address: string
  city: string
  latitude: number
  longitude: number
  ccScore: number // 1-10
  chargeScore: ChargeScore
  brewScore: BrewScore
  reliability: ReliabilityLevel
  stalls: Stall[]
  maxPowerKw: number
  connectorTypes: ConnectorType[]
  pricePerKwh: number
  amenities: Amenity[]
  lastVerified: string
  distanceMiles: number // miles from user's current position
  detourMiles: number  // miles off the planned route
  fallbackStationId: string | null
  photoCount: number
}

export interface Vehicle {
  make: string
  model: string
  year: number
  batteryKwh: number
  rangeEstimateMiles: number
  connectorType: ConnectorType
}

export type FilterCategory = "connector" | "speed" | "brand" | "utility" | "status"

export interface FilterOption {
  id: string
  label: string
  category: FilterCategory
  icon?: string
}

export function getScoreTier(score: number): { label: string; color: string } {
  if (score >= 9) return { label: "Exceptional", color: "cc-gold" }
  if (score >= 8) return { label: "Excellent", color: "cc-charge-blue" }
  if (score >= 7) return { label: "Great", color: "cc-brew-green" }
  if (score >= 6) return { label: "Good", color: "cc-caution-amber" }
  return { label: "Fair", color: "cc-alert-red" }
}
