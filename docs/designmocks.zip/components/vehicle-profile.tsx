"use client"

import { useState, useMemo } from "react"
import { cn } from "@/lib/utils"
import { vehicleOptions } from "@/lib/mock-data"
import type { Vehicle } from "@/lib/types"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import { Car, Battery, Zap, Check } from "lucide-react"

interface VehicleProfileProps {
  isOpen: boolean
  onClose: () => void
  selectedVehicle: Vehicle | null
  onSelectVehicle: (vehicle: Vehicle) => void
}

export function VehicleProfile({ isOpen, onClose, selectedVehicle, onSelectVehicle }: VehicleProfileProps) {
  const [selectedMake, setSelectedMake] = useState<string | null>(selectedVehicle?.make || null)
  const [selectedModel, setSelectedModel] = useState<string | null>(selectedVehicle?.model || null)

  const makes = useMemo(() => [...new Set(vehicleOptions.map((v) => v.make))], [])

  const modelsForMake = useMemo(
    () => vehicleOptions.filter((v) => v.make === selectedMake),
    [selectedMake]
  )

  const currentVehicle = useMemo(
    () => vehicleOptions.find((v) => v.make === selectedMake && v.model === selectedModel) || null,
    [selectedMake, selectedModel]
  )

  function handleMakeSelect(make: string) {
    setSelectedMake(make)
    setSelectedModel(null)
  }

  function handleModelSelect(model: string) {
    setSelectedModel(model)
  }

  function handleSave() {
    if (currentVehicle) {
      onSelectVehicle(currentVehicle)
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md bg-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <Car className="h-5 w-5 text-cc-charge-blue" />
            Vehicle Profile
          </DialogTitle>
          <DialogDescription>
            Set up your EV to see compatible chargers and accurate range estimates.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Make selection */}
          <div>
            <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Make
            </label>
            <div className="grid grid-cols-3 gap-2">
              {makes.map((make) => (
                <button
                  key={make}
                  type="button"
                  onClick={() => handleMakeSelect(make)}
                  className={cn(
                    "rounded-xl border px-3 py-2.5 text-sm font-medium transition-all active:scale-95",
                    selectedMake === make
                      ? "border-cc-charge-blue bg-cc-charge-blue/10 text-cc-charge-blue"
                      : "border-border bg-card text-foreground hover:bg-muted"
                  )}
                >
                  {make}
                </button>
              ))}
            </div>
          </div>

          {/* Model selection */}
          {selectedMake && (
            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Model
              </label>
              <div className="grid grid-cols-2 gap-2">
                {modelsForMake.map((v) => (
                  <button
                    key={v.model}
                    type="button"
                    onClick={() => handleModelSelect(v.model)}
                    className={cn(
                      "rounded-xl border px-3 py-2.5 text-left text-sm font-medium transition-all active:scale-95",
                      selectedModel === v.model
                        ? "border-cc-charge-blue bg-cc-charge-blue/10 text-cc-charge-blue"
                        : "border-border bg-card text-foreground hover:bg-muted"
                    )}
                  >
                    <span className="block font-semibold">{v.model}</span>
                    <span className="text-xs text-muted-foreground">{v.year}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Vehicle specs preview */}
          {currentVehicle && (
            <div className="rounded-xl border border-cc-charge-blue/20 bg-cc-charge-blue/5 p-4">
              <h4 className="mb-3 text-sm font-semibold text-cc-charge-blue">
                {currentVehicle.make} {currentVehicle.model} ({currentVehicle.year})
              </h4>
              <div className="grid grid-cols-3 gap-3">
                <div className="flex flex-col items-center gap-1 rounded-lg bg-card p-2">
                  <Battery className="h-4 w-4 text-cc-charge-blue" aria-hidden="true" />
                  <span className="text-sm font-bold text-foreground">{currentVehicle.batteryKwh}</span>
                  <span className="text-[10px] text-muted-foreground">kWh</span>
                </div>
                <div className="flex flex-col items-center gap-1 rounded-lg bg-card p-2">
                  <Car className="h-4 w-4 text-cc-brew-green" aria-hidden="true" />
                  <span className="text-sm font-bold text-foreground">{currentVehicle.rangeEstimateMiles}</span>
                  <span className="text-[10px] text-muted-foreground">mi range</span>
                </div>
                <div className="flex flex-col items-center gap-1 rounded-lg bg-card p-2">
                  <Zap className="h-4 w-4 text-cc-caution-amber" aria-hidden="true" />
                  <span className="text-sm font-bold text-foreground">{currentVehicle.connectorType}</span>
                  <span className="text-[10px] text-muted-foreground">Plug</span>
                </div>
              </div>
            </div>
          )}

          {/* Save button */}
          <button
            type="button"
            onClick={handleSave}
            disabled={!currentVehicle}
            className={cn(
              "flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold transition-all active:scale-[0.98]",
              currentVehicle
                ? "bg-cc-charge-blue text-white hover:bg-cc-charge-blue/90"
                : "bg-muted text-muted-foreground cursor-not-allowed"
            )}
          >
            <Check className="h-4 w-4" />
            Save Profile
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
